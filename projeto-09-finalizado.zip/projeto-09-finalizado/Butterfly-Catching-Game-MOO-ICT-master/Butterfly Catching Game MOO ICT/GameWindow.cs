﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Butterfly_Catching_Game_MOO_ICT
{
    public partial class GameWindow : Form
    {
        /*
         ==========================================================================================
         Contribuições e mudanças que implementei neste jogo (minha versão)
         ------------------------------------------------------------------------------------------
         • Três fases com meta e tempo:
           - Fase 1: 40s, meta 20, borboletas BRANCAS (Resources._10.gif)
           - Fase 2: 40s, meta 20, borboletas AZUIS   (Resources._06.gif)
           - Fase 3: 60s, meta 30, borboletas VERDES  (Resources._03.gif) e mais rápidas

         • Borboleta dourada reativada:
           - Usa Resources._01.gif (GIF animado)
           - Aparece com chance configurável (chanceDourada)
           - Vale 3 capturas (contabiliza +3 no progresso da fase)

         • Velocidade ajustada por fase:
           - Fases 1 e 2 mais rápidas que o original
           - Fase 3 ainda mais rápida (tanto velocidade inicial quanto nas “viradas”)

         • HUD e progressão:
           - lblTime: tempo restante
           - lblCaught: “Caught: X/meta”
           - Ao atingir a meta → NextPhase(); se o tempo zera → GameOver()

         • Spawn controlado:
           - Mantive spawnLimit e spawnTime (intervalo em ticks)
           - MakeButterfly() escolhe o GIF correto por fase e aplica chance da dourada

         • Animação de GIFs:
           - Uso do ImageAnimator (UpdateFrames no Paint e Invalidate no callback)

         • Organização do código:
           - Responsabilidades separadas: GameWindow orquestra; Butterfly representa o sprite
         ==========================================================================================
        */

        // ----------------- estado geral -----------------
        float timeLeft = 0f;         // cronômetro da fase atual
        int caught = 0;              // total geral capturado (informativo)
        int spawnTime = 0;           // contador para controlar o intervalo de spawn
        int spawnLimit = 30;         // quantidade máxima de borboletas simultâneas

        // “mundo” do jogo: todas as borboletas ativas ficam aqui
        List<Butterfly> butterfly_list = new List<Butterfly>();

        Random rand = new Random();

        // Recursos (GIFs). Observação: o array é mantido por compatibilidade,
        // mas a seleção por fase é feita explicitamente no MakeButterfly().
        Image[] butterfly_images =
        {
            Properties.Resources._01, // dourada (vale 3)
            Properties.Resources._02,
            Properties.Resources._03, // verde
            Properties.Resources._04,
            Properties.Resources._05,
            Properties.Resources._06, // azul
            Properties.Resources._07,
            Properties.Resources._08,
            Properties.Resources._09,
            Properties.Resources._10  // branca
        };

        // ----------------- fases -----------------
        int fase = 1;                // fase atual (1..3)
        int progressoFase = 0;       // soma que conta p/ meta (normal=1, dourada=3)
        int metaFase = 20;           // meta (20, 20, 30)

        // (mantidos para referência; não são usados quando trabalhamos com GIFs prontos)
        Color corFase1 = Color.DeepSkyBlue;
        Color corFase2 = Color.MediumVioletRed;
        Color corFase3 = Color.OrangeRed;

        // chance da dourada aparecer (0..100)
        int chanceDourada = 15;

        public GameWindow()
        {
            InitializeComponent();

            // IMPORTANTE: no Designer/InitializeComponent, estes eventos devem estar ligados:
            // GameTimer.Tick  += GameTimerEvent;
            // this.MouseClick += FormClickEvent;
            // this.Paint      += FormPaintEvent;

            StartPhase(1); // começa direto na fase 1
        }

        // ----------------- TIMER (loop do jogo) -----------------
        private void GameTimerEvent(object sender, EventArgs e)
        {
            // Atualiza HUD
            lblTime.Text = "Time Left: " + timeLeft.ToString("#") + ".s";
            lblCaught.Text = $"Caught: {progressoFase}/{metaFase}";

            // Decaimento do cronômetro
            timeLeft -= 0.03f;

            // Controle de spawn (intervalo + limite simultâneo)
            if (butterfly_list.Count < spawnLimit)
            {
                spawnTime--;
                if (spawnTime < 1)
                {
                    MakeButterfly();
                    spawnTime = spawnLimit; // reaplica intervalo
                }
            }

            // Movimento + colisão com bordas (bounce)
            foreach (Butterfly butterfly in butterfly_list)
            {
                // Decide se vai “virar” (velocidade) nesta iteração
                butterfly.MoveButterfly();

                // Aplica deslocamento
                butterfly.positionX += butterfly.speedX;

                // Checagem horizontal
                if (butterfly.positionX < 0 || butterfly.positionX + butterfly.width > this.ClientSize.Width)
                {
                    butterfly.speedX = -butterfly.speedX;

                    // Corrige posição para evitar grudar na borda
                    if (butterfly.positionX < 0)
                        butterfly.positionX += 10;
                    else if (butterfly.positionX + butterfly.width > this.ClientSize.Width)
                        butterfly.positionX -= 10;
                }

                // Aplica deslocamento vertical
                butterfly.positionY += butterfly.speedY;

                // Checagem vertical (deixo ~50px livres p/ HUD)
                if (butterfly.positionY < 0 || butterfly.positionY + butterfly.height > this.ClientSize.Height - 50)
                {
                    butterfly.speedY = -butterfly.speedY;

                    if (butterfly.positionY < 0)
                        butterfly.positionY += 10;
                    else if (butterfly.positionY + butterfly.height > this.ClientSize.Height - 50)
                        butterfly.positionY -= 10;
                }
            }

            // Fim de fase por tempo
            if (timeLeft < 1)
            {
                GameOver();
            }

            // Pede repintura (triggers Paint)
            this.Invalidate();
        }

        // ----------------- INPUT (clique do mouse) -----------------
        private void FormClickEvent(object sender, EventArgs e)
        {
            var mouse = (MouseEventArgs)e;

            // Percorro uma cópia (ToList) porque posso remover do original
            foreach (var butterfly in butterfly_list.ToList())
            {
                // Teste de acerto (hitbox retangular)
                bool hit =
                    mouse.X >= butterfly.positionX &&
                    mouse.Y >= butterfly.positionY &&
                    mouse.X < butterfly.positionX + butterfly.width &&
                    mouse.Y < butterfly.positionY + butterfly.height;

                if (hit)
                {
                    butterfly_list.Remove(butterfly);

                    // Dourada vale 3; normal vale 1
                    int ganho = butterfly.isGolden ? 3 : 1;
                    caught += ganho;         // total geral (informativo)
                    progressoFase += ganho;         // conta para a meta da fase

                    lblCaught.Text = $"Caught: {progressoFase}/{metaFase}";

                    // Passa de fase ao atingir a meta
                    if (progressoFase >= metaFase)
                    {
                        NextPhase();
                        return; // evita processar mais cliques nessa fase
                    }
                }
            }
        }

        // ----------------- DRAW (renderização) -----------------
        private void FormPaintEvent(object sender, PaintEventArgs e)
        {
            // Avança os frames dos GIFs ativos
            ImageAnimator.UpdateFrames();

            // Desenha todas as borboletas
            foreach (Butterfly butterfly in butterfly_list)
            {
                e.Graphics.DrawImage(
                    butterfly.butterfly_image,
                    butterfly.positionX, butterfly.positionY,
                    butterfly.width, butterfly.height
                );
            }
        }

        // ----------------- SPAWN (criação de borboletas) -----------------
        private void MakeButterfly()
        {
            Butterfly newButterFly = new Butterfly();

            // ===== Velocidade inicial (fases 1/2 rápidas e fase 3 mais rápida) =====
            int speedInicialMin, speedInicialMax;

            if (fase == 3)
            {
                // Fase 3: bem mais rápida (start + viradas agressivas)
                speedInicialMin = -12; speedInicialMax = 12;
                newButterFly.minFlip = 7;   // nas viradas, velocidade entre 7..12
                newButterFly.maxFlip = 12;
            }
            else
            {
                // Fases 1 e 2: mais rápidas que o original
                speedInicialMin = -9; speedInicialMax = 9;
                newButterFly.minFlip = 4;   // nas viradas, velocidade entre 4..9
                newButterFly.maxFlip = 9;
            }

            // Sorteio das velocidades iniciais (evito zero)
            newButterFly.speedX = rand.Next(speedInicialMin, speedInicialMax + 1);
            newButterFly.speedY = rand.Next(speedInicialMin, speedInicialMax + 1);
            if (newButterFly.speedX == 0) newButterFly.speedX = 1;
            if (newButterFly.speedY == 0) newButterFly.speedY = -1;

            // Posição inicial
            newButterFly.positionX = rand.Next(50, this.ClientSize.Width - 200);
            newButterFly.positionY = rand.Next(50, this.ClientSize.Height - 200);

            // ===== Dourada (vale 3) =====
            bool ehDourada = rand.Next(100) < chanceDourada;
            if (ehDourada)
            {
                newButterFly.isGolden = true;
                newButterFly.butterfly_image = Properties.Resources._01; // 01.gif (dourada)
                ImageAnimator.Animate(newButterFly.butterfly_image, this.OnFrameChangedHandler);
            }
            else
            {
                // ===== Imagem por fase =====
                // F1: branca (_10), F2: azul (_06), F3: verde (_03)
                Image faseImg;
                switch (fase)
                {
                    case 1: faseImg = Properties.Resources._10; break; // branca (10.gif)
                    case 2: faseImg = Properties.Resources._06; break; // azul   (06.gif)
                    case 3: faseImg = Properties.Resources._03; break; // verde  (03.gif)
                    default: faseImg = Properties.Resources._10; break;
                }

                newButterFly.butterfly_image = faseImg;
                ImageAnimator.Animate(newButterFly.butterfly_image, this.OnFrameChangedHandler);
            }

            // Adiciona no “mundo”
            butterfly_list.Add(newButterFly);
        }

        // Callback de animação (apenas repinta a tela)
        private void OnFrameChangedHandler(object? sender, EventArgs e)
        {
            this.Invalidate();
        }

        // ----------------- FASES -----------------
        private void StartPhase(int novaFase)
        {
            // Configura fase
            fase = novaFase;
            progressoFase = 0;
            butterfly_list.Clear();
            spawnTime = 0;

            // Tempo e meta por fase
            if (fase == 1) { timeLeft = 40f; metaFase = 20; }
            else if (fase == 2) { timeLeft = 40f; metaFase = 20; }
            else { timeLeft = 60f; metaFase = 30; }

            // HUD inicial
            lblTime.Text = "Time Left: " + timeLeft.ToString("#") + ".s";
            lblCaught.Text = $"Caught: 0/{metaFase}";

            // Inicia o loop
            GameTimer.Start();
        }

        private void NextPhase()
        {
            GameTimer.Stop();

            if (fase < 3)
            {
                MessageBox.Show(
                    $"Fase {fase} concluída! Indo para a fase {fase + 1}.",
                    "Parabéns", MessageBoxButtons.OK, MessageBoxIcon.Information
                );
                StartPhase(fase + 1);
            }
            else
            {
                WinGame();
            }
        }

        private void WinGame()
        {
            GameTimer.Stop();
            MessageBox.Show(
                $"Parabéns! Você concluiu as 3 fases.\nTotal capturado: {caught}",
                "Vitória", MessageBoxButtons.OK, MessageBoxIcon.Information
            );
            RestartGame(); // volta para fase 1
        }

        private void RestartGame()
        {
            // Reseta tudo para a fase 1
            this.Invalidate();
            butterfly_list.Clear();
            caught = 0;
            spawnTime = 0;
            StartPhase(1);
        }

        private void GameOver()
        {
            GameTimer.Stop();
            MessageBox.Show(
                $"Time's up! Você pegou {progressoFase}/{metaFase}. Clique OK para tentar novamente.",
                "Fim da fase", MessageBoxButtons.OK, MessageBoxIcon.Warning
            );
            RestartGame();
        }

        // ----------------- helper opcional (não utilizado com GIFs prontos) -----------------
        // Mantive para referência: gera uma borboleta desenhada em runtime com uma cor sólida.
        private Bitmap MakeColoredButterflyBitmap(Color color, int w, int h)
        {
            var bmp = new Bitmap(w, h);
            using (var g = Graphics.FromImage(bmp))
            {
                g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                using var wing = new SolidBrush(color);
                using var body = new SolidBrush(Color.FromArgb(60, 45, 45));
                using var pen = new Pen(Color.FromArgb(30, 30, 30), Math.Max(1, w / 20));

                // asas
                var r = new Rectangle(0, h / 4, w / 2, h / 2);
                g.FillEllipse(wing, r);
                r.X = w / 2;
                g.FillEllipse(wing, r);
                g.DrawEllipse(pen, new Rectangle(0, h / 4, w / 2, h / 2));
                g.DrawEllipse(pen, new Rectangle(w / 2, h / 4, w / 2, h / 2));

                // corpo
                var bodyRect = new Rectangle(w / 2 - w / 12, h / 6, w / 6, h * 2 / 3);
                g.FillEllipse(body, bodyRect);
            }
            return bmp;
        }
    }
}