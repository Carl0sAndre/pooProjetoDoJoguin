﻿using System;
using System.Drawing;

namespace Butterfly_Catching_Game_MOO_ICT
{
    // Entidade “Borboleta”: guarda imagem, posição, tamanho, velocidades e
    // a lógica de quando “vira” (troca a direção e o módulo da velocidade).
    internal class Butterfly
    {
        // Imagem a ser desenhada no Paint (GIF dos Resources)
        public Image butterfly_image;

        // Posição atual
        public int positionX;
        public int positionY;

        // Tamanho do sprite na tela
        public int height;
        public int width;

        // Velocidades (podem ser negativas/positivas)
        public int speedX, speedY;

        // Contadores usados para decidir quando trocar de direção
        public int limit, moveLimit;

        // >>> Adições desta versão <<<
        public bool isGolden = false;        // marca se é dourada (vale 3 cliques)
        public int minFlip = 2, maxFlip = 5; // faixa de velocidade quando “vira”

        // Importante: Random por instância (ok para este jogo).
        // Em cenários com muitas criações no mesmo tick, pode-se usar Random estático.
        Random rand = new Random();

        public Butterfly()
        {
            // Sorteia um limite e inicia o contador
            limit = rand.Next(200, 400);
            moveLimit = limit;

            // Velocidades iniciais (o Form ajusta ranges por fase)
            speedX = rand.Next(-5, 5);
            speedY = rand.Next(-5, 5);

            // Tamanho padrão (compatível com as imagens)
            height = 43;
            width = 60;
        }

        // Decide se é hora de “virar” a velocidade.
        // Observação: a atualização da posição (X/Y) é feita no Form, não aqui.
        public void MoveButterfly()
        {
            moveLimit--;

            if (moveLimit < 0)
            {
                // Se estava negativa, sorteia positiva entre minFlip..maxFlip;
                // se estava positiva, sorteia negativa entre -maxFlip..-minFlip.
                if (speedX < 0) speedX = rand.Next(minFlip, maxFlip + 1);
                else speedX = rand.Next(-maxFlip, -minFlip);

                if (speedY < 0) speedY = rand.Next(minFlip, maxFlip + 1);
                else speedY = rand.Next(-maxFlip, -minFlip);

                // Reinicia o contador para a próxima virada
                moveLimit = rand.Next(200, limit);
            }
        }
    }
}