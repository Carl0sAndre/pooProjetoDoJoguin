﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form2 : Form
    {
        Form3 modo_facil;
        Form1 menu_inicial;

        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Form1 f1, Form3 f3)
        {
            InitializeComponent();
            this.menu_inicial = f1;
            this.modo_facil = f3;


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            menu_inicial.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            modo_facil.Show();
            this.Hide();
        }
    }
}
