﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp2
{
    public partial class Form2 : Form
    {

        Form1 menu_inicial;

        public Form2()
        {
            InitializeComponent();
        }

        public Form2(Form1 f1)
        {
            InitializeComponent();
            this.menu_inicial = f1;


        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //menu_inicial.Show();
            menu_inicial = new Form1();
            menu_inicial.Show();
            this.Hide();
            
        }
    }
}
